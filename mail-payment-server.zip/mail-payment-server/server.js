import express from 'express';
import bodyParser from 'body-parser';
import nodemailer from 'nodemailer';
import Stripe from 'stripe';
import cors from 'cors';

const app = express();
app.use(cors());
app.use(bodyParser.json());

const stripe = new Stripe('STRIPE_SECRET_KEY'); // prendi dalla dashboard Stripe

// Endpoint per creare pagamento
app.post('/create-payment', async (req, res) => {
  try {
    const { amount, currency } = req.body;
    const paymentIntent = await stripe.paymentIntents.create({
      amount,
      currency,
    });
    res.json({ clientSecret: paymentIntent.client_secret });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Endpoint per invio email
app.post('/sendMail', async (req, res) => {
  try {
    const { email, orderId, products } = req.body;

    // products deve avere: name, price, units
    const total = products.reduce((sum, p) => sum + p.price * (p.units || 1), 0);

    const productLines = products.map(p => {
      const qty = p.units ?? 1;
      const priceUnit = p.price.toFixed(2);
      const priceTotal = (p.price * qty).toFixed(2);
      return `<li>${p.name}, ${qty} x ${priceUnit} € = ${priceTotal} €</li>`;
    }).join('');

    const htmlContent = `
      <div style="font-family: Arial, sans-serif; padding: 20px;">
        <h1>CartExpress</h1>
        <h2>Il vostro negozio di fiducia</h4><br><br>
        <h3>Conferma ordine #${orderId}</h3>
        <ul>
          ${productLines}
        </ul>
        <p><strong>Totale Carrello: €${total.toFixed(2)}</strong></p>
        <p>Grazie per il tuo ordine!</p>
      </div>
    `;

    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: 'lucavigno2003@gmail.com',
        pass: 'rlbs fqvd zwgc bbsc',
      },
    });

    await transporter.sendMail({
      from: '"CartExpress" <tuoaccount@gmail.com>',
      to: email,
      subject: `CartExpress - Conferma ordine #${orderId}`,
      html: htmlContent,
    });

    res.json({ status: 'success' });
  } catch (error) {
    res.status(500).json({ status: 'error', message: error.message });
  }
});

app.listen(5000, () => console.log('✅ Server attivo su http://localhost:5000'));
